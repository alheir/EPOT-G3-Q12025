
#ifndef PWM_GEN_H
#define PWM_GEN_H

void init_mcpwm();

void start_gen();
void stop_gen();
void set_ma(float ma);
float get_ma();
float get_freq();
void set_freq(int freq);


#endif