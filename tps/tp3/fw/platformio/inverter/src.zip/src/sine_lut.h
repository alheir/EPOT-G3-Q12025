#ifndef SINE_LUT_H
#define SINE_LUT_H
#include <stdint.h>
#include "config.h"

extern const float sine_lut[LUT_SIZE];

#endif